# SwarmGov-ZT v2 Reproducibility Package

This public repository contains the reference implementation and machine-readable experimental outputs used in the revised manuscript **“SwarmGov-ZT: Zero-Trust Runtime Governance for Trust-Aware Multi-Agent Cybersecurity Response.”**

## Scope

The package supports the controlled simulation reported in the manuscript. It is **not** a production-SOC validation package and does not claim to reproduce live enterprise deployment conditions. The benchmark uses synthetically generated policy-labelled missions. No private operational logs or personally identifiable information are included.

## Primary experiment

- 30 independent runs with fixed seeds **3100–3129**
- 4,000 missions per run; **120,000 missions** total under the default condition
- 8-agent coalition; default compromised fraction **25%**
- Compared methods: Single Agent, Centralized MAS, Role-based MAS, Swarm without ZT, and SwarmGov-ZT
- Primary SwarmGov-ZT result: **91.08% exact governance-decision accuracy** (95% CI half-width 0.17 percentage points), **92.83% macro-F1**, **93.91% compliance**, **6.09% violation**, and **2.83% false mitigation**
- Relative to Swarm without ZT, exact decision accuracy improves by **11.41 percentage points**; paired effect size **d_z = 9.93** and one-sided paired Wilcoxon **W = 465, p = 8.66e-7**

The repository also includes the 0–50% compromised-agent stress sweep, ablation results, per-class precision/recall/F1, confusion matrices, and aggregation latency microbenchmark used in Tables 4–7 and Figures 3–5 of the revised manuscript.

## Reproducibility note

The v2 reference implementation aligns the primary analysis with the manuscript-specified GRS thresholds and hard governance rules. The earlier experimental reconstruction contained an undocumented global evidence/disagreement escalation override; that implementation choice is **disabled** in the v2 primary analysis. No parameter was optimized to recover a previously reported target value.

A remaining limitation is that the recovered simulator represents each agent's risk estimate as a **scalar weighted GRS reconstruction**, while the conceptual framework defines six GRS factors. This limitation is explicitly disclosed in the revised manuscript and in `v2_implementation_notes.txt`.

## Repository structure

```text
src/
  swarmgov_zt_reproduce_v2.py
notebooks/
  SwarmGov_ZT_v2_Colab.ipynb
results/
  main/
  stress/
  ablation/
  classification/
  latency/
requirements.txt
CITATION.cff
LICENSE
v2_implementation_notes.txt
```

## Running the reference implementation

Python 3.12 is recommended.

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python src/swarmgov_zt_reproduce_v2.py
```

For Colab, open `notebooks/SwarmGov_ZT_v2_Colab.ipynb`. The code uses fixed seeds and writes result files to `swarmgov_results/`.

## Version used for the manuscript

The immutable Git commit URL recorded in the manuscript's Code Availability statement identifies the exact repository snapshot used for the revised submission. A Zenodo DOI can be added after archiving this commit/release on Zenodo.

## License

Code and repository text are released under the MIT License. Experimental CSV outputs are supplied for reproducibility of the associated manuscript.

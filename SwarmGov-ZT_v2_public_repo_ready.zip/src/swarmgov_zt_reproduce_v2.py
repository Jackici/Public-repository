"""
SwarmGov-ZT reproducibility benchmark (Colab/Python 3.12 compatible)

Grounded in the manuscript:
- 30 independent runs; fixed seeds 3100..3129
- 4,000 missions/run = 120,000 default-condition missions
- 8-agent default coalition, 25% compromised (2/8)
- risk mixture: 0.45/0.38/0.17 with Beta(2,6), Beta(3.2,3.2), Beta(5.5,2.2)
- irreversibility = 0.55*sampled_irrev + 0.45*impact + N(0,0.05)
- honest noise sd=0.095, agent bias N(0,0.018)
- compromised noise sd=0.12, risk understatement -0.24, confidence +0.06
- trust: lambda=.90, alpha=.10, delta=.02, beta=.14, eta=.10, epsilon=.05
- GRS weights = [.20,.15,.15,.20,.15,.15]
- thresholds .30/.60/.85; hard policy floors as stated in manuscript
- SciPy paired Wilcoxon test
- stress sweep: 0%, 12.5%, 25%, 37.5%, 50%, 2,000 missions/seed

IMPORTANT:
The manuscript does not fully specify the simulator's confidence/evidence-quality
generation functions, initial trust, calibration threshold, or exact mapping from
an agent's scalar risk estimate back to six GRS factors. Those are therefore
declared below as IMPLEMENTATION CHOICES, not manuscript facts. Keep them fixed
and report them if these scripts are released as Software S1.
"""

from __future__ import annotations
import json
import platform, time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
import scipy
import matplotlib
import matplotlib.pyplot as plt

# ------------------------- documented experiment constants -------------------------
SEEDS = list(range(3100, 3130))
N_RUNS = 30
MISSIONS_PER_RUN = 4000
STRESS_MISSIONS_PER_RUN = 2000
N_AGENTS = 8
DEFAULT_COMPROMISED_FRACTION = 0.25

GRS_WEIGHTS = np.array([0.20, 0.15, 0.15, 0.20, 0.15, 0.15], dtype=float)
TAU = np.array([0.30, 0.60, 0.85], dtype=float)
MIX_P = np.array([0.45, 0.38, 0.17])
BETA_PARAMS = ((2.0, 6.0), (3.2, 3.2), (5.5, 2.2))

HONEST_NOISE_SD = 0.095
AGENT_BIAS_SD = 0.018
COMP_NOISE_SD = 0.12
COMP_RISK_SHIFT = -0.24
COMP_CONF_SHIFT = +0.06

TRUST_LAMBDA = 0.90
TRUST_ALPHA = 0.10
TRUST_DELTA = 0.02
TRUST_BETA = 0.14
TRUST_ETA = 0.10
TRUST_EPS = 0.05

# ------------------------- explicit implementation choices -------------------------
# These are needed to make the paper's equations executable, but are not numerically
# specified in the manuscript text available to this notebook.
INITIAL_TRUST = 0.75
BASE_CONFIDENCE = 0.82
CONFIDENCE_NOISE_SD = 0.06
EVIDENCE_MEAN = 0.85
EVIDENCE_SD = 0.08
CALIBRATION_TOL = 0.15
DISAGREEMENT_ESCALATE_SD = 0.28
MIN_EVIDENCE_MASS = 0.75
ENABLE_UNCERTAINTY_ESCALATION = False  # v2: explicit sensitivity option, OFF in primary analysis

LABELS = np.array(["Permit", "Modify", "Escalate", "Deny"], dtype=object)
OUTDIR = Path("swarmgov_results")

@dataclass
class Mission:
    mission_id: int
    risks: np.ndarray
    oracle: int

def disposition_from_score(score: float) -> int:
    """0 Permit, 1 Modify, 2 Escalate, 3 Deny."""
    return int(np.digitize(float(score), TAU, right=False))

def oracle_decision(r: np.ndarray) -> int:
    """Equation (5) plus the manuscript's hard policy floors."""
    score = float(np.dot(GRS_WEIGHTS, r))
    d = disposition_from_score(score)
    r_auth, r_tool, r_data, r_impact, r_irrev, r_unc = r

    # hard rules stated in the manuscript
    if r_auth > 0.86 or r_tool > 0.90:
        d = max(d, 3)  # at least Deny
    if (r_impact >= 0.70 and r_irrev >= 0.70) or r_unc > 0.85:
        d = max(d, 2)  # at least Escalate
    return d

def generate_missions(rng: np.random.Generator, n: int) -> List[Mission]:
    comps = rng.choice(3, size=n, p=MIX_P)
    risks = np.empty((n, 6), dtype=float)
    for c, (a, b) in enumerate(BETA_PARAMS):
        idx = np.where(comps == c)[0]
        if len(idx):
            risks[idx] = rng.beta(a, b, size=(len(idx), 6))

    # correlate irreversibility (index 4) with impact (index 3)
    risks[:, 4] = np.clip(
        0.55 * risks[:, 4] + 0.45 * risks[:, 3] + rng.normal(0, 0.05, n),
        0, 1
    )
    return [Mission(i, risks[i], oracle_decision(risks[i])) for i in range(n)]

def choose_compromised(rng: np.random.Generator, n_agents: int, fraction: float) -> np.ndarray:
    k = int(round(n_agents * fraction))
    flags = np.zeros(n_agents, dtype=bool)
    if k > 0:
        flags[rng.choice(n_agents, size=k, replace=False)] = True
    return flags

def agent_outputs(
    rng: np.random.Generator,
    mission: Mission,
    agent_bias: np.ndarray,
    compromised: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Returns scalar risk estimates, confidence, evidence quality.

    Implementation choice: each agent estimates the mission's weighted GRS as a scalar.
    This is the smallest executable interpretation of Eq. (4) given the manuscript text.
    """
    true_score = float(np.dot(GRS_WEIGHTS, mission.risks))
    n = len(agent_bias)

    risk = np.empty(n)
    conf = np.empty(n)
    evid = np.clip(rng.normal(EVIDENCE_MEAN, EVIDENCE_SD, n), 0.05, 1.0)

    for i in range(n):
        sd = COMP_NOISE_SD if compromised[i] else HONEST_NOISE_SD
        shift = COMP_RISK_SHIFT if compromised[i] else 0.0
        risk[i] = np.clip(true_score + agent_bias[i] + rng.normal(0, sd) + shift, 0, 1)

        # confidence generation is an explicit implementation choice.
        c = BASE_CONFIDENCE - 0.35 * abs(risk[i] - true_score) + rng.normal(0, CONFIDENCE_NOISE_SD)
        if compromised[i]:
            c += COMP_CONF_SHIFT
        conf[i] = np.clip(c, 0.05, 1.0)
    return risk, conf, evid

def hard_floor_from_true_factors(r: np.ndarray, d: int) -> int:
    """Reference implementation of the manuscript's governance hard floors."""
    r_auth, r_tool, _, r_impact, r_irrev, r_unc = r
    if r_auth > 0.86 or r_tool > 0.90:
        d = max(d, 3)
    if (r_impact >= 0.70 and r_irrev >= 0.70) or r_unc > 0.85:
        d = max(d, 2)
    return d

def update_trust(
    trust: np.ndarray,
    estimates: np.ndarray,
    confidence: np.ndarray,
    oracle: int,
) -> np.ndarray:
    """
    Eq. (3): T(t+1)=clip(lambda*T + alpha*s + delta*k - beta*v - eta*h, eps,1)

    Operationalization:
      s=1 if agent disposition equals oracle
      k=1 if |confidence - correctness| <= CALIBRATION_TOL
      v=1 if agent under-responds to oracle
      h=1 if error exceeds one decision class
    """
    pred = np.array([disposition_from_score(x) for x in estimates])
    correct = (pred == oracle).astype(float)
    under = (pred < oracle).astype(float)
    harmful = (np.abs(pred - oracle) > 1).astype(float)
    calibration = (np.abs(confidence - correct) <= CALIBRATION_TOL).astype(float)

    new_t = (
        TRUST_LAMBDA * trust
        + TRUST_ALPHA * correct
        + TRUST_DELTA * calibration
        - TRUST_BETA * under
        - TRUST_ETA * harmful
    )
    return np.clip(new_t, TRUST_EPS, 1.0)

def predict_method(
    method: str,
    mission: Mission,
    estimates: np.ndarray,
    confidence: np.ndarray,
    evidence: np.ndarray,
    trust: np.ndarray,
) -> int:
    if method == "single_agent":
        return disposition_from_score(estimates[0])

    if method == "centralized_mas":
        return disposition_from_score(np.mean(estimates[:4]))

    if method == "role_based_mas":
        return disposition_from_score(np.median(estimates[:6]))

    if method == "swarm_no_zt":
        w = confidence
        score = float(np.sum(w * estimates) / max(np.sum(w), 1e-12))
        return disposition_from_score(score)

    # Full and ablations
    use_trust = method != "no_dynamic_trust"
    use_evidence = method != "no_evidence_weighting"
    use_hard_rules = method != "no_governance_rules"

    w = confidence.copy()
    if use_trust:
        w *= trust
    if use_evidence:
        w *= evidence

    score = float(np.sum(w * estimates) / max(np.sum(w), 1e-12))
    d = disposition_from_score(score)

    # manuscript says low evidence mass or high disagreement requests more evidence/escalates.
    # Threshold values here are explicit implementation choices.
    if method != "no_governance_rules" and ENABLE_UNCERTAINTY_ESCALATION:
        eff_mass = float(np.mean(w))
        disagreement = float(np.std(estimates))
        if eff_mass < MIN_EVIDENCE_MASS or disagreement > DISAGREEMENT_ESCALATE_SD:
            d = max(d, 2)

    if use_hard_rules:
        d = hard_floor_from_true_factors(mission.risks, d)
    return d

def macro_f1(y_true: np.ndarray, y_pred: np.ndarray, n_classes: int = 4) -> float:
    f1s = []
    for c in range(n_classes):
        tp = np.sum((y_true == c) & (y_pred == c))
        fp = np.sum((y_true != c) & (y_pred == c))
        fn = np.sum((y_true == c) & (y_pred != c))
        p = tp / (tp + fp) if (tp + fp) else 0.0
        r = tp / (tp + fn) if (tp + fn) else 0.0
        f1s.append(2*p*r/(p+r) if (p+r) else 0.0)
    return float(np.mean(f1s))

def compute_metrics(y: np.ndarray, p: np.ndarray) -> Dict[str, float]:
    exact = np.mean(p == y)
    violation = np.mean(p < y)       # under-response
    false_mit = np.mean(p > y)       # over-response
    compliance = np.mean(p >= y)     # at least as restrictive as oracle
    return {
        "exact": exact,
        "macro_f1": macro_f1(y, p),
        "compliance": compliance,
        "violation": violation,
        "false_mitigation": false_mit,
    }

def run_one(
    seed: int,
    n_missions: int = MISSIONS_PER_RUN,
    compromised_fraction: float = DEFAULT_COMPROMISED_FRACTION,
    methods: Tuple[str, ...] = (
        "single_agent","centralized_mas","role_based_mas",
        "swarm_no_zt","swarmgov_zt"
    ),
    save_records: bool = False,
):
    rng = np.random.default_rng(seed)
    missions = generate_missions(rng, n_missions)

    # one stable agent bias per run; compromised set fixed within a run
    agent_bias = rng.normal(0, AGENT_BIAS_SD, N_AGENTS)
    compromised = choose_compromised(rng, N_AGENTS, compromised_fraction)

    trusts = {m: np.full(N_AGENTS, INITIAL_TRUST, dtype=float) for m in methods}
    y = np.empty(n_missions, dtype=np.int8)
    preds = {m: np.empty(n_missions, dtype=np.int8) for m in methods}
    records = []

    for j, mission in enumerate(missions):
        y[j] = mission.oracle
        est, conf, evid = agent_outputs(rng, mission, agent_bias, compromised)

        for m in methods:
            preds[m][j] = predict_method(m, mission, est, conf, evid, trusts[m])

        # dynamic trust is used only by full method unless explicitly ablated.
        for m in methods:
            if m in ("swarmgov_zt", "no_evidence_weighting", "no_governance_rules"):
                trusts[m] = update_trust(trusts[m], est, conf, mission.oracle)

        if save_records:
            for m in methods:
                records.append({
                    "seed": seed, "mission_id": j,
                    "compromised_fraction": compromised_fraction,
                    "compromised_agents": ",".join(map(str, np.where(compromised)[0])),
                    "method": m,
                    "oracle": int(y[j]), "predicted": int(preds[m][j]),
                    "oracle_label": LABELS[y[j]], "predicted_label": LABELS[preds[m][j]],
                    "policy_violation": int(preds[m][j] < y[j]),
                    "false_mitigation": int(preds[m][j] > y[j]),
                })

    rows = []
    for m in methods:
        row = {"seed": seed, "method": m, "compromised_fraction": compromised_fraction}
        row.update(compute_metrics(y, preds[m]))
        rows.append(row)
    return rows, records

def ci95(x: np.ndarray) -> float:
    return 1.96 * np.std(x, ddof=1) / np.sqrt(len(x))

def aggregate(run_df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    metrics = ["exact","macro_f1","compliance","violation","false_mitigation"]
    for method, g in run_df.groupby("method", sort=False):
        row = {"method": method}
        for c in metrics:
            vals = g[c].to_numpy()
            row[c] = vals.mean()
            row[c+"_ci95"] = ci95(vals)
        rows.append(row)
    return pd.DataFrame(rows)

def main_comparison(save_records=False):
    methods = ("single_agent","centralized_mas","role_based_mas","swarm_no_zt","swarmgov_zt")
    all_rows, all_records = [], []
    for k, seed in enumerate(SEEDS, 1):
        rows, rec = run_one(seed, MISSIONS_PER_RUN, DEFAULT_COMPROMISED_FRACTION, methods, save_records)
        all_rows.extend(rows); all_records.extend(rec)
        print(f"main run {k:02d}/{N_RUNS} seed={seed}")
    df = pd.DataFrame(all_rows)
    agg = aggregate(df)

    a = df[df.method=="swarmgov_zt"].sort_values("seed")["exact"].to_numpy()
    b = df[df.method=="swarm_no_zt"].sort_values("seed")["exact"].to_numpy()
    w = wilcoxon(a, b, alternative="greater")
    return df, agg, w, pd.DataFrame(all_records)

def ablation():
    methods = ("swarmgov_zt","no_dynamic_trust","no_evidence_weighting","no_governance_rules")
    rows = []
    for k, seed in enumerate(SEEDS, 1):
        r, _ = run_one(seed, MISSIONS_PER_RUN, 0.25, methods, False)
        rows.extend(r)
        print(f"ablation {k:02d}/{N_RUNS} seed={seed}")
    df = pd.DataFrame(rows)
    return df, aggregate(df)

def stress_test():
    fractions = [0.0, 0.125, 0.25, 0.375, 0.50]
    methods = ("centralized_mas","role_based_mas","swarm_no_zt","swarmgov_zt")
    rows = []
    for frac in fractions:
        for k, seed in enumerate(SEEDS, 1):
            r, _ = run_one(seed, STRESS_MISSIONS_PER_RUN, frac, methods, False)
            rows.extend(r)
        print(f"stress fraction={frac:.3f} complete")
    df = pd.DataFrame(rows)
    out = df.groupby(["compromised_fraction","method"], as_index=False)[
        ["exact","macro_f1","compliance","violation","false_mitigation"]
    ].mean()
    return df, out

def latency_microbenchmark(repeats=20000):
    rng = np.random.default_rng(999)
    rows = []
    for n in [4,8,16,32,64]:
        T = rng.uniform(.2,1,n); C=rng.uniform(.4,1,n); E=rng.uniform(.4,1,n); R=rng.uniform(0,1,n)
        start = time.perf_counter_ns()
        for _ in range(repeats):
            w = T*C*E
            _ = np.sum(w*R)/np.sum(w)
        us = (time.perf_counter_ns()-start)/repeats/1000
        rows.append({"coalition_size":n, "mean_us_per_fusion":us})
    return pd.DataFrame(rows)

def save_figure_main(agg):
    names = ["single_agent","centralized_mas","role_based_mas","swarm_no_zt","swarmgov_zt"]
    d = agg.set_index("method").loc[names]
    x=np.arange(len(names)); width=.36
    fig, ax=plt.subplots(figsize=(10,5))
    b1=ax.bar(x-width/2,100*d["exact"],width,label="Exact")
    b2=ax.bar(x+width/2,100*d["compliance"],width,label="Compliance")
    ax.bar_label(b1,fmt="%.1f",padding=2); ax.bar_label(b2,fmt="%.1f",padding=2)
    ax.set_xticks(x,["Single","Centralized","Role-based","Swarm no ZT","SwarmGov-ZT"],rotation=15)
    ax.set_ylabel("Percent"); ax.set_ylim(0,105); ax.legend(); fig.tight_layout()
    fig.savefig(OUTDIR/"figure_main.png",dpi=200); plt.close(fig)

def save_figure_ablation(agg):
    names=["swarmgov_zt","no_dynamic_trust","no_evidence_weighting","no_governance_rules"]
    d=agg.set_index("method").loc[names]
    x=np.arange(len(names)); width=.36
    fig,ax=plt.subplots(figsize=(10,5))
    b1=ax.bar(x-width/2,100*d["exact"],width,label="Exact")
    b2=ax.bar(x+width/2,100*d["violation"],width,label="Policy violation")
    ax.bar_label(b1,fmt="%.1f",padding=2); ax.bar_label(b2,fmt="%.1f",padding=2)
    ax.set_xticks(x,["Full","No trust","No evidence","No rules"],rotation=12)
    ax.set_ylabel("Percent"); ax.set_ylim(0,105); ax.legend(); fig.tight_layout()
    fig.savefig(OUTDIR/"figure_ablation.png",dpi=200); plt.close(fig)

def save_figure_stress(stress):
    fig,ax=plt.subplots(figsize=(9,5))
    for method,g in stress.groupby("method"):
        ax.plot(100*g["compromised_fraction"],100*g["exact"],marker="o",label=method)
    ax.set_xlabel("Compromised agents (%)"); ax.set_ylabel("Exact decision rate (%)")
    ax.legend(); fig.tight_layout(); fig.savefig(OUTDIR/"figure_stress_exact.png",dpi=200); plt.close(fig)

def environment_report():
    return {
        "python": platform.python_version(),
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "pandas": pd.__version__,
        "matplotlib": matplotlib.__version__,
        "platform": platform.platform(),
        "seeds": SEEDS,
        "runs": N_RUNS,
        "missions_per_run": MISSIONS_PER_RUN,
        "total_default_missions": N_RUNS*MISSIONS_PER_RUN,
    }


def confusion_matrix4(y_true, y_pred):
    cm = np.zeros((4, 4), dtype=int)
    np.add.at(cm, (y_true, y_pred), 1)
    return cm

def per_class_metrics(y_true, y_pred):
    cm = confusion_matrix4(y_true, y_pred)
    rows = []
    for c, name in enumerate(LABELS):
        tp = cm[c, c]
        fp = cm[:, c].sum() - tp
        fn = cm[c, :].sum() - tp
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        rows.append({"class_id": c, "class_name": name, "precision": precision,
                     "recall": recall, "f1": f1, "support": int(cm[c, :].sum())})
    return pd.DataFrame(rows), cm

def paired_effect_dz(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    sd = d.std(ddof=1)
    return float(d.mean() / sd) if sd > 0 else float("inf")

def aggregate_per_class(per_seed_class_df):
    rows = []
    for (method, cid, cname), g in per_seed_class_df.groupby(["method","class_id","class_name"], sort=False):
        r = {"method": method, "class_id": cid, "class_name": cname,
             "mean_support": float(g["support"].mean())}
        for metric in ["precision","recall","f1"]:
            vals = g[metric].to_numpy()
            r[metric] = vals.mean()
            r[metric+"_ci95"] = ci95(vals)
        rows.append(r)
    return pd.DataFrame(rows)


def run_all(save_mission_records=False):
    OUTDIR.mkdir(exist_ok=True)
    print(environment_report())

    main_df, main_agg, wtest, records = main_comparison(save_mission_records)
    abl_df, abl_agg = ablation()
    stress_df, stress_agg = stress_test()
    latency = latency_microbenchmark()

    main_df.to_csv(OUTDIR/"main_per_run.csv",index=False)
    main_agg.to_csv(OUTDIR/"table4_main_aggregate.csv",index=False)
    abl_df.to_csv(OUTDIR/"ablation_per_run.csv",index=False)
    abl_agg.to_csv(OUTDIR/"table6_ablation_aggregate.csv",index=False)
    stress_df.to_csv(OUTDIR/"stress_per_run.csv",index=False)
    stress_agg.to_csv(OUTDIR/"table5_stress_aggregate.csv",index=False)
    latency.to_csv(OUTDIR/"table7_latency.csv",index=False)
    if save_mission_records:
        records.to_csv(OUTDIR/"main_mission_records.csv",index=False)

    with open(OUTDIR/"environment.json","w",encoding="utf-8") as f:
        json.dump(environment_report(),f,indent=2)

    with open(OUTDIR/"statistics.txt","w",encoding="utf-8") as f:
        f.write(f"Paired one-sided Wilcoxon, SwarmGov-ZT > Swarm without ZT, exact accuracy\n")
        f.write(f"statistic={wtest.statistic}\npvalue={wtest.pvalue}\n")

    save_figure_main(main_agg)
    save_figure_ablation(abl_agg)
    save_figure_stress(stress_agg)

    print("\n=== Main comparison (%; mean ± 95% CI) ===")
    for _,r in main_agg.iterrows():
        print(f"{r.method:22s} exact={100*r.exact:6.2f} ± {100*r.exact_ci95:5.2f} | "
              f"F1={100*r.macro_f1:6.2f} | compliance={100*r.compliance:6.2f} | "
              f"violation={100*r.violation:6.2f}")
    print("\nWilcoxon:", wtest)
    print("\nOutputs:", OUTDIR.resolve())
    return main_df, main_agg, abl_df, abl_agg, stress_df, stress_agg, latency

if __name__ == "__main__":
    run_all(save_mission_records=False)


def run_all_v2(save_mission_records=False):
    """
    Reviewer-grade v2 analysis. Primary change from v1:
    undocumented global escalation is disabled. This prevents the implementation
    choice from forcing most low-risk missions into Escalate.

    NOTE: this still uses the scalar-risk reconstruction because the manuscript
    did not preserve the original six-factor agent-observation implementation.
    Therefore v2 outputs must replace, not be tuned to, old manuscript results.
    """
    global ENABLE_UNCERTAINTY_ESCALATION
    ENABLE_UNCERTAINTY_ESCALATION = False

    OUTDIR.mkdir(exist_ok=True)
    methods = ("single_agent","centralized_mas","role_based_mas","swarm_no_zt","swarmgov_zt")
    run_rows, class_rows, records_all = [], [], []
    total_cm = {m: np.zeros((4,4), dtype=int) for m in methods}

    for k, seed in enumerate(SEEDS, 1):
        # Reproduce the paired mission stream, while retaining predictions for class analysis.
        rng = np.random.default_rng(seed)
        missions = generate_missions(rng, MISSIONS_PER_RUN)
        agent_bias = rng.normal(0, AGENT_BIAS_SD, N_AGENTS)
        compromised = choose_compromised(rng, N_AGENTS, DEFAULT_COMPROMISED_FRACTION)
        trusts = {m: np.full(N_AGENTS, INITIAL_TRUST, dtype=float) for m in methods}
        y = np.empty(MISSIONS_PER_RUN, dtype=np.int8)
        preds = {m: np.empty(MISSIONS_PER_RUN, dtype=np.int8) for m in methods}

        for j, mission in enumerate(missions):
            y[j] = mission.oracle
            est, conf, evid = agent_outputs(rng, mission, agent_bias, compromised)
            for m in methods:
                preds[m][j] = predict_method(m, mission, est, conf, evid, trusts[m])
            for m in methods:
                if m in ("swarmgov_zt",):
                    trusts[m] = update_trust(trusts[m], est, conf, mission.oracle)
            if save_mission_records:
                for m in methods:
                    records_all.append({"seed":seed,"mission_id":j,"method":m,
                        "oracle":int(y[j]),"predicted":int(preds[m][j]),
                        "oracle_label":LABELS[y[j]],"predicted_label":LABELS[preds[m][j]],
                        "policy_violation":int(preds[m][j] < y[j]),
                        "false_mitigation":int(preds[m][j] > y[j])})

        for m in methods:
            r = {"seed": seed, "method": m, "compromised_fraction": DEFAULT_COMPROMISED_FRACTION}
            r.update(compute_metrics(y, preds[m]))
            run_rows.append(r)
            pc, cm = per_class_metrics(y, preds[m])
            pc.insert(0, "method", m); pc.insert(0, "seed", seed)
            class_rows.append(pc)
            total_cm[m] += cm
        print(f"v2 main {k:02d}/30 seed={seed}")

    main_df = pd.DataFrame(run_rows)
    class_df = pd.concat(class_rows, ignore_index=True)
    main_agg = aggregate(main_df)
    class_agg = aggregate_per_class(class_df)

    # paired effect sizes and Wilcoxon
    wide = main_df.pivot(index="seed", columns="method", values="exact")
    stat_rows = []
    ref = wide["swarmgov_zt"].to_numpy()
    for other in ["single_agent","centralized_mas","role_based_mas","swarm_no_zt"]:
        x = wide[other].to_numpy()
        diff = ref - x
        w = wilcoxon(ref, x, alternative="greater")
        stat_rows.append({"comparison":f"swarmgov_zt - {other}",
            "mean_difference":float(diff.mean()), "ci95":ci95(diff),
            "effect_dz":paired_effect_dz(ref,x),
            "wilcoxon_stat":float(w.statistic),"p_value":float(w.pvalue)})
    stats_df = pd.DataFrame(stat_rows)

    # full ablation, same paired seeds
    abl_df, abl_agg = ablation()

    # exports
    main_df.to_csv(OUTDIR/"v2_main_per_run.csv",index=False)
    main_agg.to_csv(OUTDIR/"v2_table4_main_aggregate.csv",index=False)
    class_df.to_csv(OUTDIR/"v2_per_class_per_seed.csv",index=False)
    class_agg.to_csv(OUTDIR/"v2_per_class_aggregate.csv",index=False)
    stats_df.to_csv(OUTDIR/"v2_paired_effects.csv",index=False)
    abl_df.to_csv(OUTDIR/"v2_ablation_per_run_COMPLETE.csv",index=False)
    abl_agg.to_csv(OUTDIR/"v2_table6_ablation_aggregate.csv",index=False)
    if save_mission_records:
        pd.DataFrame(records_all).to_csv(OUTDIR/"v2_mission_records.csv",index=False)

    cm_rows=[]
    for m,cm in total_cm.items():
        pd.DataFrame(cm,index=LABELS,columns=LABELS).to_csv(OUTDIR/f"v2_confusion_{m}.csv")
        for i,t in enumerate(LABELS):
            for j,p in enumerate(LABELS):
                cm_rows.append({"method":m,"true_label":t,"predicted_label":p,"count":int(cm[i,j])})
    pd.DataFrame(cm_rows).to_csv(OUTDIR/"v2_confusion_all.csv",index=False)

    # confusion plot
    cm=total_cm["swarmgov_zt"]
    fig,ax=plt.subplots(figsize=(6,5))
    im=ax.imshow(cm)
    ax.set_xticks(range(4),LABELS); ax.set_yticks(range(4),LABELS)
    ax.set_xlabel("Predicted"); ax.set_ylabel("Oracle"); ax.set_title("SwarmGov-ZT v2 confusion matrix")
    for i in range(4):
        for j in range(4):
            ax.text(j,i,str(cm[i,j]),ha="center",va="center")
    fig.colorbar(im,ax=ax); fig.tight_layout()
    fig.savefig(OUTDIR/"v2_confusion_swarmgov_zt.png",dpi=200); plt.close(fig)

    with open(OUTDIR/"v2_implementation_notes.txt","w",encoding="utf-8") as f:
        f.write("Primary analysis disables the undocumented global evidence/disagreement escalation override.\n")
        f.write("No parameter was optimized against the manuscript's old target results.\n")
        f.write("Scalar-risk reconstruction remains an implementation limitation and must be disclosed.\n")

    print("\n=== v2 main results (%) ===")
    for _,r in main_agg.iterrows():
        print(f"{r.method:22s} Exact={100*r.exact:6.2f}±{100*r.exact_ci95:5.2f} "
              f"F1={100*r.macro_f1:6.2f} Compliance={100*r.compliance:6.2f} "
              f"Violation={100*r.violation:6.2f} FalseMit={100*r.false_mitigation:6.2f}")
    print("\nPaired effects:\n", stats_df.to_string(index=False))
    return main_agg, class_agg, stats_df, abl_agg
